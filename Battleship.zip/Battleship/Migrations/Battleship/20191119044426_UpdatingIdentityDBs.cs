﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Battleship.Migrations.Battleship
{
    public partial class UpdatingIdentityDBs : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
